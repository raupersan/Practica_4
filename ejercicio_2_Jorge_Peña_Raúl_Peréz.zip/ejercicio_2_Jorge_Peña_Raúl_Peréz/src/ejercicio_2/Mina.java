package ejercicio_2;

public class Mina {
	Posicion pos;
	public Mina(Posicion pos) {
		this.pos = pos;
	}
	public Posicion getPos() {
		return pos;
	}
	public void setPos(Posicion pos) {
		this.pos = pos;
	}
}
