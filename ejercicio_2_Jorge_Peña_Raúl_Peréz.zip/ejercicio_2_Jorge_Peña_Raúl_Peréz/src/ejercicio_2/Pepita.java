package ejercicio_2;

public class Pepita {

}
