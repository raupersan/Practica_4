package ejercicio_2;

	public enum Tipo {JUGADOR, PEPITA, MINA, VOID}
	
